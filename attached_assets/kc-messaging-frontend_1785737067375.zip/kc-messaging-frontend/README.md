# KC Messaging — frontend

React + TypeScript + Vite client built to match `kc-messaging-backend` exactly —
every request in `src/lib/api.ts` and every socket event in `src/lib/socket.ts`
mirrors that repo's controllers, DTOs, and gateway with nothing added or renamed.

## Contract match

| Frontend call | Backend route |
|---|---|
| `api.sendOtp(phone)` | `POST /auth/otp/send` |
| `api.verifyOtp(phone, code, platform)` | `POST /auth/otp/verify` → stores `{ accessToken, refreshToken, deviceId }` |
| single-flight refresh in `request()` | `POST /auth/refresh` |
| `api.logout()` | `POST /auth/logout` |
| `api.me()` | `GET /users/me` |
| `api.listConversations()` | `GET /conversations` |
| `api.createConversation(participantIds, title)` | `POST /conversations` |
| `api.getMessages(id, cursor, limit)` | `GET /conversations/:id/messages` |
| `api.sendMessage(id, body)` | `POST /conversations/:id/messages` |
| `api.markRead(id)` | `POST /conversations/:id/read` |
| `connectSocket()` | `io('<url>/realtime', { auth: { token } })` |
| `emitTypingStart/Stop` | `typing:start` / `typing:stop` |
| socket `message:new`, `typing:update` | gateway broadcasts of the same names |

`deviceId` is generated once with `crypto.randomUUID()` and persisted in
`localStorage` alongside the token pair, since the backend keys refresh
tokens and push tokens per `Device` row, not per user.

There's no user-directory endpoint in the backend, so "start a new chat"
takes a participant's raw user id (as returned by `GET /users/me` for any
account) rather than inventing a search endpoint the backend doesn't have.

## Setup

```bash
npm install
cp .env.example .env   # point at your running kc-messaging-backend
npm run dev
```

Run `kc-messaging-backend` first (see its own README), and set
`CORS_ORIGIN` there to this app's dev origin (`http://localhost:5173` by
default).
